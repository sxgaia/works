from logica import sala
from logica import sessao

def imprimir_sala(sala):
    print ("Número Sala ",  sala[0])
    print ("Lotação ", sala[1])
    
    print ()

def menu_adicionar():
    print ("\nAdicionar sala \n")
    numero_sala = int(input("numero da sala: "))
    lotacao = int (input("lotação:"))
    print(" Status da Sala")

    if lotacao>0:

        print("sala ocupada")
    else:
        print("sala livre")
    
    sala.adicionar_sala(numero_sala, lotacao)


        

def menu_listar():
    print ("\nListar salas \n")
    salas = sala.listar_salas()
    for a in salas:
        imprimir_sala(a)


def menu_buscar():
    print ("\nBuscar sala por Número da Sala \n")
    numero_sala = int(input("Número da sala "))
    a = sala.buscar_sala(numero_sala)
    if (a == None):
        print ("sala não encontrado")
    else:
        imprimir_sala(a)
  
def menu_remover():
    print ("\nRemover sala \n")
    numero_sala = int(input("Número da Sala "))
    a = sala.remover_sala(numero_sala)
    if (a == False):
        print ("sala não encontrado")
    else:
        print ("sala removido")
    

def mostrar_menu():
    run_sala = True
    menu = ("\n----------------\n"+
             "(1) Adicionar nova sala \n" +
             
             "(2) Listar salas \n" +
             "(3) Buscar sala por numero da sala \n" +
             "(4) Remover sala \n" +
             "(0) Voltar\n"+
            "----------------")
    
    while(run_sala):
        print (menu)
        op = int(input("Digite sua escolha: "))

        if (op == 1):
            menu_adicionar()
          
        elif(op == 2):
            menu_listar()
        elif(op == 3):       
            menu_buscar()
        elif (op == 4):
            menu_remover()
        elif (op == 0):
            run_sala = False

if __name__ == "__main__":
    mostrar_menu()
    
