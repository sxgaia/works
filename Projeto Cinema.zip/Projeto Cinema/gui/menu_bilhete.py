from logica import bilhete

def imprimir_bilhete(bilhete):
    print ("Número Bilhete",  bilhete[0])
    
    
    print ("Número da Sessão", bilhete[1])
    print ("venda Bilhete",  bilhete[2])
    
    print ()

def menu_adicionar():
    print ("\nVenda Bilhete \n")
    numero_bilhete = int(input("Número do Bilhete: "))
    
    
    numero_sessao= int(input("Número da Sessão:"))
    venda_bilhete=str(input("digite i para inteira e m para meia:"))
    if venda_bilhete == "i":

        print ("Bilhete valor Inteira: R$ 10,00" )
    if venda_bilhete == "m":
        print ("Bilhete valor meia: R$ 5,00")
        bilhete.adicionar_bilhete(numero_bilhete,numero_sessao,venda_bilhete)

def menu_listar():
    print ("\nListar bilhetes \n")
    bilhetes = bilhete.listar_bilhetes()
    for b in bilhetes:
        imprimir_bilhete(b)


    

       

def menu_buscar():
    print ("\nBuscar Bilhete por Número do Bilhete \n")
    numero_bilhete = int(input("Número do Bilhete: "))
    b = bilhete.buscar_bilhete(numero_bilhete)
    if (b == None):
        print ("Bilhete não encontrado")
    else:
        imprimir_bilhete(b)
  
def menu_remover():
    print ("\nRemover bilhete \n")
    numero_bilhete = int(input("Número do Bilhete: "))
    b = bilhete.remover_bilhete(numero_bilhete)
    if (b == False):
        print ("bilhete não encontrado")
    else:
        print ("bilhete removido")
    

def mostrar_menu():
    run_bilhete = True
    menu = ("\n----------------\n"+
             "(1) Venda Bilhete  \n" +
             "(2) Listar Bilhetes \n" +
             "(3) Buscar Bilhete por Número \n" +
             "(4) Remover Bilhete \n" +
             "(0) Voltar\n"+
            "----------------")
    
    while(run_bilhete):
        print (menu)
        op = int(input("Digite sua escolha: "))

        if (op == 1):
            menu_adicionar()
        elif(op == 2):
            menu_listar()
        elif(op == 3):
            menu_buscar()
        elif (op == 4):
            menu_remover()
        elif (op == 0):
            run_bilhete = False

if __name__ == "__main__":
    mostrar_menu()
    
