from logica import sessao
from logica import bilhete
from logica import sala


def imprimir_sessao(sessao):
    print ("Número Sessão",  sessao[0])
    print ("Número Filme: ", sessao[1])
    print ("Número Sala: ",  sessao[2])
    print ("Horário",sessao [3])
    print ()

def menu_adicionar():
    print ("\nAdicionar sessão \n")
    numero_sessao = int(input("Número Sessão "))
    numero_filme = int (input("Número Filme "))
    numero_sala = int(input("Número Sala "))
    horario=float(input("Horário"))
    sessao.adicionar_sessao(numero_sessao, numero_filme, numero_sala,horario)

def menu_listar():
    print ("\nListar sessoes \n")
    sessoes = sessao.listar_sessoes()
    for s in sessoes:
        imprimir_sessao(s)




def menu_buscar():
    print ("\nBuscar sessao por Número da Sessão \n")
    numero_sessao = int(input("Número sessão: "))
    s = sessao.buscar_sessao(numero_sessao)
    if (s == None):
        print ("sessao não encontrado")
    else:
        imprimir_sessao(s)
  
def menu_remover():
    print ("\nRemover sessão \n")
    numero_sessao = int(input("Número sessão "))
    s = sessao.remover_sessao(numero_sessao)
    if (s == False):
        print ("sessão não encontrado")
    else:
        print ("sessão removido")
    

def mostrar_menu():
    run_sessao = True
    menu = ("\n----------------\n"+
             "(1) Adicionar nova Sessão \n" +
             "(2) Listar sessões \n" +
             
             "(3) Buscar sessão por Númro de sessão \n" +
             "(4) Remover sessão \n" +
             "(0) Voltar\n"+
            "----------------")
    
    while(run_sessao):
        print (menu)
        op = int(input("Digite sua escolha: "))

        if (op == 1):
            menu_adicionar()
        elif(op == 2):
            menu_listar()
           
        elif(op == 3):       
            menu_buscar()
        elif (op == 4):
            menu_remover()
        elif (op == 0):
            run_sessao = False

if __name__ == "__main__":
    mostrar_menu()
    
