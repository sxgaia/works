from logica import elenco
from logica import filme
from logica import ator




def imprimir_elenco(elenco):
    print ("Número do elenco",  elenco[0])
    print ("Número do Ator ", elenco[1])
    print ("Número do Filme ",  elenco[2])
    print ()

def menu_adicionar():
    print ("\nAdicionar Elenco \n")
    numero_elenco = int(input("Número Elenco "))
    numero_ator= int (input("Número Ator "))
    numero_filme = int(input("Número Filme "))
    elenco.adicionar_elenco(numero_elenco, numero_ator, numero_filme)

def menu_listar():
    print ("\nListar elenco \n")
    elencos = elenco.listar_elencos()
    for e in elencos:
        imprimir_elenco(e)

def menu_buscar():
    print ("\nBuscar Elenco por Número do Elenco \n")
    numero_elenco = int(input("Número Elenco "))
    e = elenco.buscar_elenco(numero_elenco)
    if (e == None):
        print ("Elenco não encontrado")
    else:
        imprimir_elenco(e)


def menu_buscar_filme():
    print ("\nBuscar Elenco por Número do Filme \n")
    numero_filme = int(input("Número Filme "))
    e = elenco.buscar_elenco(numero_filme)
    if (e == None):
        print ("Elenco não encontrado")
    else:
        imprimir_elenco(e)

        
  
def menu_remover():
    print ("\nRemover elenco \n")
    numero_elenco = int(input("Número Elenco "))
    e = elenco.remover_elenco(numero_elenco)
    if (e == False):
        print ("Elenco não encontrado")
    else:
        print ("Elenco removido")
    

def mostrar_menu():
    run_elenco = True
    menu = ("\n----------------\n"+
             "(1) Adicionar novo filme \n" +
             "(2) Buscar elenco por Número do elenco \n" +
             "(3) Buscar elenco por Número do Filme \n" +
             "(4) Remover elenco \n" +
             "(5) Listar elenco \n" +
             "(0) Voltar\n"+
            "----------------")
    
    while(run_elenco):
        print (menu)
        op = int(input("Digite sua escolha: "))

        if (op == 1):
            menu_adicionar()
        elif(op == 2):       
            menu_buscar()
        elif(op == 3):       
            menu_buscar_filme()
        elif (op == 4):
            menu_remover()
        elif (op == 5):
            menu_listar()
        elif (op == 0):
            run_elenco = False

if __name__ == "__main__":
    mostrar_menu()
    
