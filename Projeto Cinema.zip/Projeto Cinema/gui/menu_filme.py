from logica import filme

def imprimir_filme(filme):
    print ("Numero do Filme ",  filme[0])
    print ("Titulo ", filme[1])
    print ("Duração ",  filme[2])
    print ("Classificação ",  filme[3])
    print ("Diretor",  filme[4])
    print ("Distribuidora", filme[5])
    print ("Gênero ",  filme[6])
    print ()

def menu_adicionar():
    print ("\nAdicionar Filme \n")
    numero_filme = int(input("Número Filme: "))
    titulo = str (input("Titulo: "))
    duracao = str(input("Duração: "))
    classificacao = str(input("Classificação:"))
    diretor = str(input("Diretor "))
    distribuidora = str(input("Distribuidora: "))
    genero=str(input("Gênero:"))
    filme.adicionar_filme(numero_filme,titulo,duracao,classificacao,diretor,distribuidora, genero)

def menu_listar():
    print ("\nListar Filmes \n")
    filmes = filme.listar_filmes()
    for f in filmes:
        imprimir_filme(f)


def menu_buscar():
    print ("\nBuscar Filme por Número do Filme \n")
    numero_filme = int(input("Número Filme "))
    f = filme.buscar_filme(numero_filme)
    if (f == None):
        print ("Filme não encontrado")
    else:
        imprimir_filme(f)
  
def menu_remover():
    print ("\nRemover filme \n")
    numero_filme = int(input("Número do Filme "))
    f = filme.remover_filme(numero_filme)
    if (f == False):
        print ("filme não encontrado")
    else:
        print ("filme removido")
    

def mostrar_menu():
    run_filme = True
    menu = ("\n----------------\n"+
             "(1) Adicionar novo filme \n" +
             "(2) Listar filmes \n" +
             "(3) Buscar filme por Número do Filme \n" +
             "(4) Remover filme \n" +
             "(0) Voltar\n"+
            "----------------")
    
    while(run_filme):
        print (menu)
        op = int(input("Digite sua escolha: "))

        if (op == 1):
            menu_adicionar()
        elif(op == 2):
            menu_listar()
        elif(op == 3):       
            menu_buscar()
        elif (op == 4):
            menu_remover()
        elif (op == 0):
            run_filme = False

if __name__ == "__main__":
    mostrar_menu()
    
