from logica import ator

def imprimir_ator(ator):
    print ("Número do ator ",  ator[0])
    print ("Nome: ", ator[1])
    print ("Nacionalidade ",  ator[2])
    print ()

def menu_adicionar():
    print ("\nAdicionar Ator \n")
    numero_ator = int(input("Número do Ator "))
    nome = str (input("Nome: "))
    nacionalidade = str(input("Nacionalidade: "))
    ator.adicionar_ator(numero_ator, nome, nacionalidade)

def menu_listar():
    print ("\nListar atores \n")
    atores = ator.listar_atores()
    for r in atores:
        imprimir_ator(r)


def menu_buscar():
    print ("\nBuscar ator por Número do Ator \n")
    numero_ator = int(input("Número Ator: "))
    r = ator.buscar_ator(numero_ator)
    if (r == None):
        print ("ator não encontrado")
    else:
        imprimir_ator(r)
  
def menu_remover():
    print ("\nRemover ator \n")
    numero_ator = int(input("Número do Ator "))
    r = ator.remover_ator(numero_ator)
    if (r == False):
        print ("ator não encontrado")
    else:
        print ("ator removido")
    

def mostrar_menu():
    run_ator = True
    menu = ("\n----------------\n"+
             "(1) Adicionar novo ator \n" +
             "(2) Listar atores \n" +
             "(3) Buscar ator por Número do ator \n" +
             "(4) Remover ator \n" +
             "(0) Voltar\n"+
            "----------------")
    
    while(run_ator):
        print (menu)
        op = int(input("Digite sua escolha: "))

        if (op == 1):
            menu_adicionar()
        elif(op == 2):
            menu_listar()
        elif(op == 3):       
            menu_buscar()
        elif (op == 4):
            menu_remover()
        elif (op == 0):
            run_ator = False

if __name__ == "__main__":
    mostrar_menu()
    
