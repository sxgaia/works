elencos = []


def adicionar_elenco(numero_elenco, numero_ator, numero_filme):    
    elenco = [numero_elenco, numero_ator, numero_filme]
    elencos.append(elenco)
    
def listar_elencos():
    return elencos

def buscar_elenco(numero_elenco):
    for e in elencos:
        if (e[0] == numero_elenco):
            return e
    return None

def buscar_filme(numero_filme):
    for e in elencos:
        if (e[0] == numero_elenco):
            return e
    return None
        
def remover_elenco(numero_elenco):
    for e in elencos:
        if (e[0] == numero_elenco):
            elencos.remove(e)
            return True
    return False
      
def remover_todos_elencos():
    global elencos
    elencos =  [] 
    
def iniciar_elencos():
    adicionar_elenco(7777, 9999, 2222)
    adicionar_elenco(8888, 4444, 1111)
    
