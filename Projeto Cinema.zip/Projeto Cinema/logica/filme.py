filmes = []


def adicionar_filme(numero_filme,titulo,duracao,classificacao,diretor,distribuidora, genero):    
    filme = [numero_filme,titulo,duracao,classificacao,diretor,distribuidora, genero]
    filmes.append(filme)
    
def listar_filmes():
    return filmes

def buscar_filme(numero_filme):
    for f in filmes:
        if (f[0] == numero_filme):
            return f
    return None
        
def remover_filme(numero_filme):
    for f in filmes:
        if (f[0] == numero_filme):
            filmes.remove(f)
            return True
    return False
      
def remover_todos_filmes():
    global filmes
    filmes =  [] 
    
def iniciar_filmes():
    adicionar_filme(2222,"Os Trapalhões","2:00","livre","bony","Globo", "Comédia")
    adicionar_filme(1111,"Vem de Carona","2:00","livre","bony","Globo", "Comédia")
    
