bilhetes = []




def adicionar_bilhete(numero_bilhete, numero_sessao,venda_bilhete):    
    bilhete = [numero_bilhete, numero_sessao,venda_bilhete]
    bilhetes.append(bilhete)
    
def listar_bilhetes():
    return bilhetes

def venda():
    return None

def buscar_bilhete(numero_bilhete):
    for b in bilhetes:
        if (b[0] == numero_bilhete):
            return b
    return None

        
def remover_bilhete(numero_bilhete):
    for b in bilhetes:
        if (b[0] == numero_bilhete):
            bilhetes.remove(b)
            return True
    return False
      
def remover_todos_bilhetes():
    global bilhetes
    bilhetes =  [] 
    
def iniciar_bilhetes():
    adicionar_bilhete(2222, 33333, "m" )
    adicionar_bilhete(1111, 44444, "m" )
    

