atores = []


def adicionar_ator(numero_ator, nome, nacionalidade):    
    ator = [numero_ator, nome, nacionalidade]
    atores.append(ator)
    
def listar_atores():
    return atores

def buscar_ator(numero_ator):
    for r in atores:
        if (r[0] == numero_ator):
            return r
    return None
        
def remover_ator(numero_ator):
    for r in atores:
        if (r[0] == numero_ator):
            atores.remove(r)
            return True
    return False
      
def remover_todos_atores():
    global atores
    atores =  [] 
    
def iniciar_atores():
    adicionar_ator(9999, "Carlos", "brasileiro")
    adicionar_ator(4444, "Maria", "brasileiro")
    
