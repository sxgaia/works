salas = []


def adicionar_sala(numero_sala, lotacao):    
    sala = [numero_sala, lotacao]
    salas.append(sala)



    
def listar_salas():
    return salas

def buscar_sala(numero_sala):
    for a in salas:
        if (a[0] == numero_sala):
            return a
    return None

def remover_sala(numero_sala):
    for a in salas:
        if (a[0] == numero_sala):
            salas.remove(a)
            return True
    return False
      
def remover_todas_salas():
    global salas
    salas =  [] 
    
def iniciar_salas():
    adicionar_sala(2222,50)
    adicionar_sala(1111, 50)
    

