sessoes = []


def adicionar_sessao(numero_sessao, numero_filme, numero_sala, horario):    
    sessao = [numero_sessao, numero_filme, numero_sala, horario]
    sessoes.append(sessao)
    
def listar_sessoes():
    return sessoes

def lotacao():
    return l


def buscar_sessao(numero_sessao):
    for s in sessoes:
        if (s[0] == numero_sessao):
            return s
    return None
        
def remover_sessao(numero_sessao):
    for s in sessoes:
        if (s[0] == numero_sessao):
            sessoes.remove(s)
            return True
    return False
      
def remover_todas_sessoes():
    global sessoes
    sessoes =  [] 
    
def iniciar_sessoes():
    adicionar_sessao(2222, 5555, 1, "10:00")
    adicionar_sessao(1111, 6666, 2, "11:00")
    

