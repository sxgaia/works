import unittest

from logica import filme

class TestFilme(unittest.TestCase):
    
    def setUp(self):
        filme.remover_todos_filmes()
        
    def test_sem_filmes(self):
        filmes = filme.listar_filmes()
        self.assertEqual(0, len(filmes))
        
    def test_adicionar_um_filme(self):
        filme.adicionar_filme(2222,"Os Trapalhões","2:00","livre","bony","Globo", "Comédia")

        filmes = filme.listar_filmes()
        self.assertEqual(1, len(filmes))

        f = filmes[0]

        self.assertEqual(2222, f[0])
        self.assertEqual("Os Trapalhões", f[1])
        self.assertEqual("2:00", f[2])
        self.assertEqual("livre", f[3])
        self.assertEqual("bony", f[4])
        self.assertEqual("Globo", f[5])
        self.assertEqual("Comédia", f[6])
  
    def test_adicionar_dois_filme(self):
        filme.adicionar_filme(2222,"Os Trapalhões","2:00","livre","bony","Globo", "Comédia")
        filme.adicionar_filme(1111,"Vem de Carona","2:00","livre","bony","Globo", "Comédia")

        filmes = filme.listar_filmes()
        self.assertEqual(2, len(filmes))
 
    def test_buscar_filme(self):
        filme.adicionar_filme(2222,"Os Trapalhões","2:00","livre","bony","Globo", "Comédia")
        filme.adicionar_filme(1111,"Vem de Carona","2:00","livre","bony","Globo", "Comédia")

        f = filme.buscar_filme(2222)
        self.assertEqual(2222, f[0])
        self.assertEqual("Os Trapalhões", f[1])
 
    def test_remover_filme(self):
       filme.adicionar_filme(2222,"Os Trapalhões","2:00","livre","bony","Globo", "Comédia")
       filme.adicionar_filme(1111,"Vem de Carona","2:00","livre","bony","Globo", "Comédia")

       filme.remover_filme(2222)

       f = filme.buscar_filme(2222)
       self.assertIsNone(f)
  
    def test_remover_todos_filmes(self):
        filme.adicionar_filme(2222,"Os Trapalhões","2:00","livre","bony","Globo", "Comédia")
        filme.adicionar_filme(1111,"Vem de Carona","2:00","livre","bony","Globo", "Comédia")

        filme.remover_todos_filmes()

        f = filme.listar_filmes()
        self.assertEqual([], f)
  

    def test_iniciar_filmes(self)  :
        filme.iniciar_filmes()
        filmes = filme.listar_filmes()
        self.assertEqual(2, len(filmes))
        
        
            
if __name__ == '__main__':
    unittest.main(exit=False)
