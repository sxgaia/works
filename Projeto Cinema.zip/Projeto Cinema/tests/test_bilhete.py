import unittest

from logica import bilhete

class TestBilhete(unittest.TestCase):
    
    def setUp(self):
        bilhete.remover_todos_bilhetes()
        
    def test_sem_bilhetes(self):
        bilhetes = bilhete.listar_bilhetes()
        self.assertEqual(0, len(bilhetes))
        
    def test_adicionar_um_bilhete(self):
        bilhete.adicionar_bilhete(2222, 33333, "m")

        bilhetes = bilhete.listar_bilhetes()
        self.assertEqual(1, len(bilhetes))

        b = bilhetes[0]

        self.assertEqual(2222, b[0])
        self.assertEqual(33333, b[1])
        self.assertEqual("m", b[2])
  
    def test_adicionar_dois_bilhete(self):
        bilhete.adicionar_bilhete(2222, 33333, "m")
        bilhete.adicionar_bilhete(1111, 44444, "m")

        bilhetes = bilhete.listar_bilhetes()
        self.assertEqual(2, len(bilhetes))
 
    def test_buscar_bilhete(self):
        bilhete.adicionar_bilhete(2222, 33333, "m")
        bilhete.adicionar_bilhete(1111, 44444, "m")

        b = bilhete.buscar_bilhete(2222)
        self.assertEqual(2222, b[0])
        self.assertEqual(33333, b[1])
 
    def test_remover_bilhete(self):
       bilhete.adicionar_bilhete(2222, 33333, "m")
       bilhete.adicionar_bilhete(1111, 44444, "m")

       bilhete.remover_bilhete(2222)

       b = bilhete.buscar_bilhete(2222)
       self.assertIsNone(b)
  
    def test_remover_todos_bilhetes(self):
        bilhete.adicionar_bilhete(2222, 33333, "m")
        bilhete.adicionar_bilhete(1111, 44444, "m")

        bilhete.remover_todos_bilhetes()

        b = bilhete.listar_bilhetes()
        self.assertEqual([], b)
  

    def test_iniciar_bilhetes(self)  :
        bilhete.iniciar_bilhetes()
        bilhetes = bilhete.listar_bilhetes()
        self.assertEqual(2, len(bilhetes))
        
        
            
if __name__ == '__main__':
    unittest.main(exit=False)
