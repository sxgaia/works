import unittest

from logica import elenco

class TestElenco(unittest.TestCase):
    
    def setUp(self):
        elenco.remover_todos_elencos()
        
    def test_sem_elencos(self):
        elencos = elenco.listar_elencos()
        self.assertEqual(0, len(elencos))
        
    def test_adicionar_um_elenco(self):
        elenco.adicionar_elenco(7777, 9999, 2222)

        elencos = elenco.listar_elencos()
        self.assertEqual(1, len(elencos))

        e = elencos[0]

        self.assertEqual(7777, e[0])
        self.assertEqual(9999, e[1])
        self.assertEqual(2222, e[2])
  
    def test_adicionar_dois_elenco(self):
        elenco.adicionar_elenco(7777, 9999, 2222)
        elenco.adicionar_elenco(8888, 4444, 1111)

        elencos = elenco.listar_elencos()
        self.assertEqual(2, len(elencos))
 
    def test_buscar_elenco(self):
        elenco.adicionar_elenco(7777, 9999, 2222)
        elenco.adicionar_elenco(8888, 4444, 1111)

        e = elenco.buscar_elenco(7777)
        self.assertEqual(7777, e[0])
        self.assertEqual(9999, e[1])
 
    def test_remover_elenco(self):
       elenco.adicionar_elenco(7777, 9999, 2222)
       elenco.adicionar_elenco(8888, 4444, 1111)

       elenco.remover_elenco(7777)

       e = elenco.buscar_elenco(7777)
       self.assertIsNone(e)
  
    def test_remover_todos_elencos(self):
        elenco.adicionar_elenco(7777, 9999, 2222)
        elenco.adicionar_elenco(8888, 4444, 1111)

        elenco.remover_todos_elencos()

        e = elenco.listar_elencos()
        self.assertEqual([], e)
  

    def test_iniciar_elencos(self)  :
        elenco.iniciar_elencos()
        elencos = elenco.listar_elencos()
        self.assertEqual(2, len(elencos))
        
        
            
if __name__ == '__main__':
    unittest.main(exit=False)
