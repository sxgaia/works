import unittest

from logica import sessao

class TestSessao(unittest.TestCase):
    
    def setUp(self):
        sessao.remover_todas_sessoes()
        
    def test_sem_sessoes(self):
        sessoes = sessao.listar_sessoes()
        self.assertEqual(0, len(sessoes))
        
    def test_adicionar_um_sessao(self):
        sessao.adicionar_sessao(2222, 5555, 1, "10:00")

        sessoes = sessao.listar_sessoes()
        self.assertEqual(1, len(sessoes))

        s = sessoes[0]

        self.assertEqual(2222, s[0])
        self.assertEqual(5555, s[1])
        self.assertEqual(1, s[2])
        self.assertEqual("10:00", s[3])
  
    def test_adicionar_dois_sessao(self):
        sessao.adicionar_sessao(2222, 5555, 1, "10:00")
        sessao.adicionar_sessao(1111, 6666, 2, "11:00")

        sessoes = sessao.listar_sessoes()
        self.assertEqual(2, len(sessoes))
 
    def test_buscar_sessao(self):
        sessao.adicionar_sessao(2222, 5555, 1, "10:00")
        sessao.adicionar_sessao(1111, 6666, 2, "11:00")

        s = sessao.buscar_sessao(2222)
        self.assertEqual(2222, s[0])
        self.assertEqual(5555, s[1])
 
    def test_remover_sessao(self):
       sessao.adicionar_sessao(2222, 5555, 1, "10:00")
       sessao.adicionar_sessao(1111, 6666, 2, "11:00")

       sessao.remover_sessao(2222)

       s = sessao.buscar_sessao(2222)
       self.assertIsNone(s)
  
    def test_remover_todas_sessoes(self):
        sessao.adicionar_sessao(2222, 5555, 1, "10:00")
        sessao.adicionar_sessao(1111, 6666, 2, "11:00")

        sessao.remover_todas_sessoes()

        s = sessao.listar_sessoes()
        self.assertEqual([], s)
  

    def test_iniciar_sessoes(self)  :
        sessao.iniciar_sessoes()
        sessoes = sessao.listar_sessoes()
        self.assertEqual(2, len(sessoes))
        
        
            
if __name__ == '__main__':
    unittest.main(exit=False)
