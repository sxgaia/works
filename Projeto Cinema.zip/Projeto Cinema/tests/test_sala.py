import unittest

from logica import sala

class TestSala(unittest.TestCase):
    
    def setUp(self):
        sala.remover_todas_salas()
        
    def test_sem_salas(self):
        salas = sala.listar_salas()
        self.assertEqual(0, len(salas))
        
    def test_adicionar_um_sala(self):
        sala.adicionar_sala(2222,50)

        salas = sala.listar_salas()
        self.assertEqual(1, len(salas))

        a = salas[0]

        self.assertEqual(2222, a[0])
        self.assertEqual(50, a[1])
        
  
    def test_adicionar_dois_sala(self):
        sala.adicionar_sala(2222, 50)
        sala.adicionar_sala(1111, 50)

        salas = sala.listar_salas()
        self.assertEqual(2, len(salas))
 
    def test_buscar_sala(self):
        sala.adicionar_sala(2222, 50)
        sala.adicionar_sala(1111, 50)

        a = sala.buscar_sala(2222)
        self.assertEqual(2222, a[0])
        self.assertEqual(50, a[1])
 
    def test_remover_sala(self):
       sala.adicionar_sala(2222, 50)
       sala.adicionar_sala(1111, 50)

       sala.remover_sala(2222)

       a = sala.buscar_sala(2222)
       self.assertIsNone(a)
  
    def test_remover_todas_salas(self):
        sala.adicionar_sala(2222, 50)
        sala.adicionar_sala(1111, 50)

        sala.remover_todas_salas()

        a = sala.listar_salas()
        self.assertEqual([], a)
  

    def test_iniciar_salas(self)  :
        sala.iniciar_salas()
        salas = sala.listar_salas()
        self.assertEqual(2, len(salas))
        
        
            
if __name__ == '__main__':
    unittest.main(exit=False)
