import unittest

from logica import ator

class TestAtor(unittest.TestCase):
    
    def setUp(self):
        ator.remover_todos_atores()
        
    def test_sem_atores(self):
        atores = ator.listar_atores()
        self.assertEqual(0, len(atores))
        
    def test_adicionar_um_ator(self):
        ator.adicionar_ator(9999, "Carlos", "brasileiro")

        atores = ator.listar_atores()
        self.assertEqual(1, len(atores))

        r = atores[0]

        self.assertEqual(9999, r[0])
        self.assertEqual("Carlos", r[1])
        self.assertEqual("brasileiro", r[2])
  
    def test_adicionar_dois_ator(self):
        ator.adicionar_ator(9999, "Carlos", "brasileiro")
        ator.adicionar_ator(4444, "Maria", "brasileiro")

        atores = ator.listar_atores()
        self.assertEqual(2, len(atores))
 
    def test_buscar_ator(self):
        ator.adicionar_ator(9999, "Carlos", "brasileiro")
        ator.adicionar_ator(4444, "Maria", "brasileiro")

        r = ator.buscar_ator(9999)
        self.assertEqual(9999, r[0])
        self.assertEqual("Carlos", r[1])
 
    def test_remover_ator(self):
       ator.adicionar_ator(9999, "Carlos", "brasileiro")
       ator.adicionar_ator(4444, "Maria", "brasileiro")

       ator.remover_ator(9999)

       r = ator.buscar_ator(9999)
       self.assertIsNone(r)
  
    def test_remover_todos_atores(self):
        ator.adicionar_ator(9999, "Carlos", "brasileiro")
        ator.adicionar_ator(4444, "Maria", "brasileiro")

        ator.remover_todos_atores()

        r = ator.listar_atores()
        self.assertEqual([], r)
  

    def test_iniciar_atores(self)  :
        ator.iniciar_atores()
        atores = ator.listar_atores()
        self.assertEqual(2, len(atores))
        
        
            
if __name__ == '__main__':
    unittest.main(exit=False)
